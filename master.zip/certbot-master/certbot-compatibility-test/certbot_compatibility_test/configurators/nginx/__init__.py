"""Certbot compatibility test Nginx configurators"""
