.. acme-python documentation master file, created by
   sphinx-quickstart on Sun Oct 18 13:38:06 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to acme-python's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2

   api

.. automodule:: acme
   :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

