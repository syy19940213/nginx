local function close_redis(redis_instance)
    if not redis_instance then
        return
    end
    local ok,err = redis_instance:close();
    if not ok then
        ngx.say("close redis error : ",err);
    end
end

local redis = require "resty.redis"

local ip = ngx.var.remote_addr
local red = redis:new()

local ok, err = red:set_keepalive(60000, 20)

red:set_timeouts(1000, 1000, 1000) -- 1 sec

local ok, err = red:connect("118.31.108.209", 6379)
if not ok then
   ngx.say("failed to connect: ", err)
   return
end
local ck = ngx.var.cookie_ccinfo
local res, err = red:get(ngx.var.remote_addr)
if res == ngx.null then
  if ck == nil then
    ngx.exec('/code.html')
  else
    red:set(ngx.var.remote_addr,1)
    red:expire(ngx.var.remote_addr, 86400)
  end
else
   local count = tonumber(res) 
   count = count + 1 
   local res, err =  red:set(ngx.var.remote_addr,count)
   red:expire(ngx.var.remote_addr, 86400)	
end

close_redis(red)

